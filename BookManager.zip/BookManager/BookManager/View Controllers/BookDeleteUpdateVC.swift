//
//  BookDeleteUpdateVC.swift
//  BookManager
//
//  Created by Gandham, Bharath on 11/7/19.
//  Copyright © 2019 Gandham, Bharath. All rights reserved.
//

import UIKit

class BookDeleteUpdateVC: UIViewController {
    var cid = ""
      
    @IBOutlet weak var txtauthor: UITextField!
    
    @IBOutlet weak var txtdue: UITextField!
    @IBOutlet weak var txtsubject: UITextField!
    @IBOutlet weak var txttitle: UITextField!
    private var datePicker1: UIDatePicker?
          
          var oldRecord: NSArray!
          
          override func viewDidLoad() {
              super.viewDidLoad()

            
              txttitle.becomeFirstResponder()
              
              var eachDetail = BooksCRUD().fetchdetail(cid: cid as NSString)
              txttitle.text = eachDetail[0] as? String
              txtauthor.text = eachDetail[1] as? String
              txtsubject.text = eachDetail[2] as? String
              txtdue.text = eachDetail[3] as? String
              
              datePicker1 = UIDatePicker()
              datePicker1?.datePickerMode = .date
              datePicker1?.addTarget(self, action: #selector(dateChanged(datePicker:)), for: .valueChanged)
                         
              let tapGesture = UITapGestureRecognizer(target: self, action: #selector(viewTapped(gestureRecognizer:)))
                         
              view.addGestureRecognizer(tapGesture)
                         
              txtdue.inputView = datePicker1
              
              
          }

    @IBAction func btnactupdate(_ sender: Any) {
        dismiss(animated: true, completion: nil)
        
        var title:NSString = txttitle?.text as! NSString
         var author:NSString = txtauthor?.text as! NSString
         var subject:NSString = txtsubject?.text as! NSString
        var due:NSString = txtdue?.text as! NSString
         BooksCRUD().update( oldrecord: oldRecord, newrecord: NSArray(objects: title,author,subject,due))
        
    }
    
     
    @IBAction func btnactdelete(_ sender: Any) {
              dismiss(animated: true, completion: nil)
              
              var title:NSString = txttitle?.text as! NSString
              var author:NSString = txtauthor?.text as! NSString
              var subject:NSString = txtsubject?.text as! NSString
              var due:NSString = txtdue?.text as! NSString
              
              var record:NSArray = NSArray()
              record = NSArray(objects: title,author,subject,due)
              BooksCRUD().delete(record: record)
              
          }

         @objc func viewTapped(gestureRecognizer: UITapGestureRecognizer)
         {
             view.endEditing(true)
         }
         @objc func dateChanged(datePicker: UIDatePicker)
         {
             let dateFormatter = DateFormatter()
             dateFormatter.dateFormat = "MM/dd/yyyy"
             
             txtdue.text = dateFormatter.string(from: datePicker.date)
             view.endEditing(true)
             
         }

     
      }
