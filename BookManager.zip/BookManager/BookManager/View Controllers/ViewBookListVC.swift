//
//  ViewBookListVC.swift
//  BookManager
//
//  Created by Gandham, Bharath on 11/7/19.
//  Copyright © 2019 Gandham, Bharath. All rights reserved.
//

import UIKit

class ViewBookListVC: UIViewController {
    var cid = ""
           var cidpass = ""
          
    @IBOutlet weak var lblsubject1: UILabel!
    @IBOutlet weak var lbltitle1: UILabel!
    @IBOutlet weak var lbltitle: UILabel!
    
    @IBOutlet weak var lbldue1: UILabel!
    @IBOutlet weak var lblauthor1: UILabel!
    @IBOutlet weak var lbldue: UILabel!
    @IBOutlet weak var lblsubject: UILabel!
    @IBOutlet weak var lblauthor: UILabel!
           
           override func viewDidLoad() {
               
               super.viewDidLoad()

               // Do any additional setup after loading the view.
               
              
             
               var eachDetail = BooksCRUD().fetchdetail(cid: cid as NSString)
               cidpass = eachDetail[0] as! String
               lbltitle1.text = eachDetail[0] as? String
               lblauthor1.text = eachDetail[1] as? String
               lblsubject1.text = eachDetail[2] as? String
               lbldue1.text = eachDetail[3] as? String
           }
           override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
               if segue.identifier == "DetailToUpdate"{
                   if let updateVC = segue.destination as? BookDeleteUpdateVC{
                       updateVC.cid = cidpass
                       print("Coming in details to update ==== ")
                       updateVC.oldRecord = NSArray(objects: lbltitle1.text, lblauthor1.text,lblsubject1.text,lbldue1.text)
                   }
               }
           }

   
    @IBAction func btnactupdatedeletebook(_ sender: Any)
       {
           performSegue(withIdentifier: "DetailToUpdate", sender: self)
       }
           
           
       }
