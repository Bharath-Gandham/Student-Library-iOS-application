//
//  BooksCRUD.swift
//  BookManager
//
//  Created by Gandham, Bharath on 11/7/19.
//  Copyright © 2019 Gandham, Bharath. All rights reserved.
//

import UIKit
import CoreData

class BooksCRUD: NSObject {
     var context: NSManagedObjectContext?
        
        func getManagedObjectContext() -> NSManagedObjectContext{
            let appDelegate = UIApplication.shared.delegate as? AppDelegate
            let managedContext = (appDelegate?.persistentContainer.viewContext)!
            return managedContext
        }
        
        func fetchall() -> NSMutableArray{
                //Get the managed context context from AppDelegate
                if(context == nil) {
                    context = self.getManagedObjectContext()
                }
                //Create a new empty record.
                let booksEntity = NSEntityDescription.entity(forEntityName: "BookManager", in: context!)

                let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "BookManager")
                fetchRequest.entity = booksEntity

                fetchRequest.sortDescriptors = [NSSortDescriptor.init(key: "duedate", ascending: true)]
                let error = NSError()
                var getRecord: NSMutableArray = NSMutableArray()
                do
                {
                    let result = try context!.fetch(fetchRequest)
                    if(result.count > 0)
                    {
                        for i in 0..<result.count
                        {
                            var recordObj : BookManager = result[i] as! BookManager
                            getRecord.add(recordObj)
                        }
                    }

                }
                catch let error as NSError{
                    print("result not found!\(error),\(error.userInfo)")
                }
                
                    
                return getRecord
            }
            
        func fetchdetail(cid: NSString) -> NSMutableArray{
            //Get the managed context context from AppDelegate
            if(context == nil) {
                context = self.getManagedObjectContext()
            }
            
            //Create a new empty record.
            let booksEntity : NSEntityDescription = NSEntityDescription.entity(forEntityName: "BookManager", in: context!)!
            
            //Prepare the request of type NSFetchRequest  for the entity (SELECT * FROM)
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "BookManager")
            fetchRequest.entity = booksEntity
            fetchRequest.predicate = NSPredicate(format: "title = %@", cid)
            
            
            let error = NSError()
            
            var getRecord: NSMutableArray = NSMutableArray()
            
            do{
                let result = try context!.fetch(fetchRequest)
                
                if(result.count > 0)
                {
                    for i in 0..<result.count
                    {
                        var recordObj : BookManager = result[i] as! BookManager
                        
                        var b1 : NSString = NSString(format: "%@", recordObj.title!)
                        var b2 : NSString = NSString(format: "%@", recordObj.author!)
                        var b3 : NSString = NSString(format: "%@", recordObj.subject!)
                        var b4 : NSString = NSString(format: "%@", recordObj.duedate!)
                        
                        getRecord = NSMutableArray(objects: b1,b2,b3,b4)
                      
                    }
                }
                
            }
            catch let error as NSError{
                print("result not found!\(error),\(error.userInfo)")
            }
            return getRecord
        }
        
        func addline(record:NSArray) -> Bool{
                //Get the managed context context from AppDelegate
                
                if(context == nil) {
                    context = self.getManagedObjectContext()
                }
            
                var recordObj = NSEntityDescription.insertNewObject(forEntityName: "BookManager", into: context!)
                       recordObj.setValue(record[0], forKey: "title")
                       recordObj.setValue(record[1], forKey: "author")
                       recordObj.setValue(record[2], forKey: "subject")
                       recordObj.setValue(record[3], forKey: "duedate")
                
                print("title", record[0])
                do
                {
                    //Save the managed object context
                    try context!.save()
                }
                catch let error as NSError
                {
                    print("Could not create the new record! \(error), \(error.userInfo)")
                }
                return true
            }
        
        func delete(record:NSArray) -> Bool
        {
            //Get the managed context context from AppDelegate
            
            if(context == nil)
            {
                context = self.getManagedObjectContext()
            }
            //Create a new empty record.
            let booksEntity : NSEntityDescription = NSEntityDescription.entity(forEntityName: "BookManager", in: context!)!
            
            //Prepare the request of type NSFetchRequest  for the entity (SELECT * FROM)
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "BookManager")
            fetchRequest.entity = booksEntity
            fetchRequest.predicate = NSPredicate(format: "title = %@", record.object(at: 0) as! String)
            print("fetchRequest = ", fetchRequest)
            
            let error = NSError()
            do
            {
               // let result = try context.fetch(fetchRequest) as! NSMutableArray
                let result = try context!.fetch(fetchRequest)
                let recordToDelete = result[0] as! NSManagedObject
                context!.delete(recordToDelete)
                
                do
                {
                    //Save the managed object context
                    try context!.save()
                } catch let error as NSError {
                    print("Could not create the new record! \(error), \(error.userInfo)")
                }
                for rec in fetchall() {
                    print("rec = ", rec)
                }
            }
            catch let error as NSError {
                print("result not found")
            }
            return true
            
        }
        
        func update(oldrecord:NSArray, newrecord:NSArray) -> Bool{
               //Get the managed context context from AppDelegate
               if(context == nil) {
                   context = self.getManagedObjectContext()
               }
               
               //Create a new empty record.
               let booksEntity :NSEntityDescription = NSEntityDescription.entity(forEntityName: "BookManager", in: context!)!
               
               //Prepare the request of type NSFetchRequest  for the entity (SELECT * FROM)
               let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "BookManager")
               fetchRequest.entity = booksEntity
               fetchRequest.predicate = NSPredicate(format: "title = %@", oldrecord.object(at: 0) as! String)
               let error = NSError()
               //let recordObj = NSEntityDescription.entity(forEntityName: "Books", in: context)!
               let recordObj = NSEntityDescription.insertNewObject(forEntityName: "BookManager", into: context!)
               recordObj.setValue(newrecord[0], forKey: "title")
               recordObj.setValue(newrecord[1], forKey: "author")
               recordObj.setValue(newrecord[2], forKey: "subject")
               recordObj.setValue(newrecord[3], forKey: "duedate")
               
               print("\n #####################################\n")
               for attr in newrecord {
                   print("attr from update", attr)
               }
               do {
                   //Save the managed object context
                   try context!.save()
               } catch let error as NSError {
                   print("Could not create the new record! \(error), \(error.userInfo)")
               }
               
               do{
                  // let result = try context.fetch(fetchRequest) as! NSMutableArray
                   let result = try context!.fetch(fetchRequest)
                   let recordToDelete = result[0] as! NSManagedObject
                   context!.delete(recordToDelete)
                   
                   do {
                       //Save the managed object context
                       try context!.save()
                   } catch let error as NSError {
                       print("Could not create the new record! \(error), \(error.userInfo)")
                   }
                   for rec in fetchall() {
                       print("rec = ", rec)
                   }
               }
               catch let error as NSError {
                   print("result not found")
               }
               return true
           }

    }
