//
//  BookListVC.swift
//  BooksCRUD
//
//  Created by Gandham, Bharath on 11/7/19.
//  Copyright © 2019 Gandham, Bharath. All rights reserved.
//

import UIKit

class BookListVC: UITableViewController {
    
    
    
    var getAll: NSMutableArray!
           var cidpass = ""
           override func viewDidLoad() {
               super.viewDidLoad()
               
               tableView.delegate = self
               tableView.dataSource = self
              
               getAll = BooksCRUD().fetchall()
           }

           override func numberOfSections(in tableView: UITableView) -> Int {
               return 1
           }

           override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
              return getAll.count
           }

           
           override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
               let cell = tableView.dequeueReusableCell(withIdentifier: "BookCell", for: indexPath) as! BookListCellVC

            let d : BookManager = getAll[indexPath.row] as! BookManager
            let title : NSString = d.title! as NSString
            let author : NSString = d.author! as NSString
            let subject : NSString = d.subject! as NSString
            let duedate : NSString = d.duedate! as NSString
               
               cell.lblTitle.text = title as String
               cell.lblDueDate.text = duedate as String
               
               print("title = ", title)
               
               cell.accessoryType = UITableViewCell.AccessoryType.disclosureIndicator
               return cell
           }
           

           override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
                 var d1 : BookManager = getAll[indexPath.row] as! BookManager
               var pass : NSString = d1.title as! NSString
               cidpass = pass as String
               
               
               
               performSegue(withIdentifier: "ListToDetail", sender: self)
               
               
               
           }
       
       override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
               if segue.identifier == "ListToDetail"
               {
                   if let detailVC = segue.destination as? ViewBookListVC{
                       detailVC.cid = cidpass
                   }
               }
           }
           
           
           @IBAction func SegueueFunctionAdd(_ sender: UIStoryboardSegue) {
               print("Calling from unwindAddSegue")
               getAll = BooksCRUD().fetchall()
               print("Reloading Data..")
               tableView.reloadData()
           }
           
           @IBAction func SegueueFunctionDelete(_ sender: UIStoryboardSegue) {
               print("Calling from unwindDeleteSegue")
               getAll = BooksCRUD().fetchall()
               print("Reloading Data..")
               tableView.reloadData()
           }
           
           @IBAction func SegueueFunctionUpdate(_ sender: UIStoryboardSegue) {
               print("Calling from unwindUpdateSegue")
               getAll = BooksCRUD().fetchall()
               print("Reloading Data..")
               tableView.reloadData()
           }
       }
