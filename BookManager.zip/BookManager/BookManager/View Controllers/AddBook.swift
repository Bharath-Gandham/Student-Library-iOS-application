//
//  AddBook.swift
//  BookManager
//
//  Created by Gandham, Bharath on 11/7/19.
//  Copyright © 2019 Gandham, Bharath. All rights reserved.
//

import UIKit

class AddBook: UIViewController {
    
    
      
    @IBOutlet weak var txtAuthor: UITextField!
    @IBOutlet weak var txtDue: UITextField!
    @IBOutlet weak var txtSubject: UITextField!
    @IBOutlet weak var txtTitle: UITextField!
    private var datePicker: UIDatePicker?
      
      
           
          override func viewDidLoad() {
              super.viewDidLoad()
              // Do any additional setup after loading the view.
               txtTitle.becomeFirstResponder()
              
              datePicker = UIDatePicker()
              datePicker?.datePickerMode = .date
              datePicker?.addTarget(self, action: #selector(dateChanged(datePicker:)), for: .valueChanged)
              
              let tapGesture = UITapGestureRecognizer(target: self, action: #selector(AddBook.viewTapped(gestureRecognizer:)))
              
              view.addGestureRecognizer(tapGesture)
              
              txtDue.inputView = datePicker
              
             }
      @objc func viewTapped(gestureRecognizer: UITapGestureRecognizer)
      {
          view.endEditing(true)
      }
      @objc func dateChanged(datePicker: UIDatePicker)
      {
          let dateFormatter = DateFormatter()
          dateFormatter.dateFormat = "MM/dd/yyyy"
          
          txtDue.text = dateFormatter.string(from: datePicker.date)
          view.endEditing(true)
          
      }
    
    @IBAction func btnactaddbook(_ sender: Any) {
        
      dismiss(animated: true, completion: nil)
        
      var bookTitle : NSString = txtTitle?.text as! NSString
         var author : NSString = txtAuthor?.text as! NSString
         var subject : NSString = txtSubject?.text as! NSString
         var dueBy : NSString = txtDue?.text as! NSString
       
        var record : NSArray = NSArray()
         record = NSArray(objects: bookTitle,author,subject,dueBy)
    }
    
      
     
      
      // MARK: - Navigation
          // In a storyboard-based application, you will often want to do a little preparation before navigation
          override func prepare(for segue: UIStoryboardSegue, sender: Any?)
          {
                     var bookTitle : NSString = txtTitle?.text as! NSString
                var author : NSString = txtAuthor?.text as! NSString
                var subject : NSString = txtSubject?.text as! NSString
                var dueBy : NSString = txtDue?.text as! NSString
              
               var record : NSArray = NSArray()
                record = NSArray(objects: bookTitle,author,subject,dueBy)
               BooksCRUD().addline(record: record)
          }
      }
